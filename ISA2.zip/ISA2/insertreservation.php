<?php
// Database connection (assuming $con is your PDO connection)
include 'connect.php';

 //var_dump($_POST); // Debugging

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = isset($_POST['username']) ? trim($_POST['username']) : null;
    $email = isset($_POST['email']) ? trim($_POST['email']) : null;
    $room_id = isset($_POST['room_id']) ? trim($_POST['room_id']) : null;
    $guests = isset($_POST['guests']) ? trim($_POST['guests']) : null;
    


    try {
        $insertQuery = $con->prepare("INSERT INTO reservation (username, email ,room_id, guests) VALUES (?,?,?,?)");
        $insertQuery->bindParam(1, $username);
        $insertQuery->bindParam(2, $email);
        $insertQuery->bindParam(3, $room_id);
        $insertQuery->bindParam(4, $guests);


        if ($insertQuery->execute()) {
            header("Location:reservation.html");  
            exit();
        } else {
            $errorInfo = $insertQuery->errorInfo();
            echo "Error: " . $errorInfo[2];
        }
    } catch (PDOException $e) {
        echo "Database Error: " . $e->getMessage();
    }
} else {
    die("Invalid request.");
}
?>
