
    function validateForm(event) {
        event.preventDefault();

        let isValid = true;

        // Username Validation (3-15 characters, letters and numbers only)
        const username = document.getElementById('username').value;
        const usernameError = document.getElementById('usernameError');
        const usernamePattern = /^[a-zA-Z0-9]{3,15}$/;

        if (!usernamePattern.test(username)) {
            usernameError.textContent = "Username must be 3-15 characters and contain only letters and numbers.";
            isValid = false;
        } else {
            usernameError.textContent = "";
        }

        // Email Validation (Standard email format)
        const email = document.getElementById('email').value;
        const emailError = document.getElementById('emailError');
        const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

        if (!emailPattern.test(email)) {
            emailError.textContent = "Please enter a valid email address.";
            isValid = false;
        } else {
            emailError.textContent = "";
        }

        // If validation passes, show the popover
        if (isValid) {
            document.getElementById('popover').style.display = 'block';
        }

        return false; // Prevent form submission for demo purposes
    }

    function closePopover() {
        document.getElementById('popover').style.display = 'none';
    }