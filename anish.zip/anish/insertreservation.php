<?php
// Database connection credentials
$host = "localhost";     // XAMPP server runs locally
$username = "root";      // Default XAMPP MySQL username
$password = "";          // No password by default
$database = "demo";      // Database name

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Capture form data
$username = $_POST['username'];
$email = $_POST['email'];
$room_id = $_POST['room_id'];
$guests = $_POST['guests'];

// Prevent SQL injection and sanitize inputs
$username = $conn->real_escape_string($username);
$email = $conn->real_escape_string($email);
$room_id = $conn->real_escape_string($room_id);
$guests = (int)$guests;

// Prepare and bind SQL statement
$stmt = $conn->prepare("INSERT INTO reservation (username, email, room_id, guests) VALUES (?, ?, ?, ?)");
$stmt->bind_param("sssi", $username, $email, $room_id, $guests);

if ($stmt->execute()) {
    echo "<h2>Reservation successful!</h2>";
    echo "<p>Thank you, $username, for booking the $room_id room for $guests guest(s).</p>";
} else {
    echo "Error: " . $stmt->error;
}

// Close connections
$stmt->close();
$conn->close();
?>
